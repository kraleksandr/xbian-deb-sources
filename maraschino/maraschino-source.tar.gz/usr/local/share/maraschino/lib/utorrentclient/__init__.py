# -*- coding: utf-8 -*-
# Copyright (c) 2008-2011 Erik Svensson <erik.public@gmail.com>
# Licensed under the MIT license.

from utorrentclient.utorrent import uTorrent

__author__    = u'Erik Svensson <erik.public@gmail.com>'
__version__   = u'0.8'
__copyright__ = u'Copyright (c) 2008-2011 Erik Svensson'
__license__   = u'MIT'
